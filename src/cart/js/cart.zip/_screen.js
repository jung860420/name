
import Requester from './_requester';

export default class Screen extends Requester {

	construntor () {

		const SCOPE = this;

	}
}